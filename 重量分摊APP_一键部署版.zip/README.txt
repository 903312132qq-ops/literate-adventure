

iPhone部署步骤

1、打开：https://vercel.com

2、Apple账号登录

3、点 Add New → Project

4、把 index.html 上传

5、等待生成网址

6、Safari打开网址

7、底部分享按钮 → 添加到主屏幕

完成。

